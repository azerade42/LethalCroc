# Lethal Croc

lethal company if it was cool (swaps the scavenger model into a croc)

![croc_crouch](https://github.com/azerade42/LethalCroc/assets/56888291/82db0f4d-d0c1-48b7-8283-61516c8a8ebf)

## Future Plans
* Adding suit variants to the shop!

## Known Issues
* Item positions are quite a bit off, especially the two-handed ones

## Credits
ModelReplacementAPI: [Bunya](https://github.com/BunyaPineTree/LethalCompany_ModelReplacementAPI/)

Model/Textures: [Luzzy](https://twitter.com/luzzyderay)

Unity/Programming: [Aze](https://twitter.com/azerade_)

EZSoftBone package (used for tail): [EZhex1991](https://assetstore.unity.com/packages/tools/physics/ezsoftbone-148136)

![croc_standing](https://github.com/azerade42/LethalCroc/assets/56888291/0fcfdda5-ef6c-47d2-83c4-74a5dc4da299)
